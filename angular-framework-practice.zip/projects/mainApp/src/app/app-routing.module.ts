import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

//custom components
import { AppDynamicPageComponent } from './components/app-dynamic-page/app-dynamic-page.component';

const routes: Routes = [
  { path: '', component: AppDynamicPageComponent, data: { title: 'Document Header', parameter : 'documentHeader' } }, 
  { path: 'workFlow', component: AppDynamicPageComponent, data: { title: 'Document Workflow', parameter : 'documentWorkFlow' } }, 
  { path: 'detatils', component: AppDynamicPageComponent, data: { title: 'Document Details', parameter : 'documentDetails' } }, 
  { path: '**', component: AppDynamicPageComponent, data: { title: 'Page Not Found', parameter : '404-error' } }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: []
})
export class AppRoutingModule { }
