import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { ReactiveFormsModule } from '@angular/forms';

//3rd pary imports
import { EditorModule } from 'primeng/editor';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { ChipsModule } from 'primeng/chips';
import { TableModule } from 'primeng/table';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

//custom components
import { AppComponent } from './app.component';
import { AppRoutingModule } from '../app/app-routing.module';
import { AppDynamicPageComponent } from '../app/components/app-dynamic-page/app-dynamic-page.component';
import { AbstractViewComponent } from '../app/components/abstract-view/abstract-view.component';
import { WidgetTextEditorComponent } from '../app/ui-widgets/text-editor/widget-texteditor.component';
import { DatepickerComponent } from '../app/ui-widgets/datepicker/datepicker.component';
import { RadiobuttonComponent } from '../app/ui-widgets/radiobutton/radiobutton.component';
import { FormsubmitComponent } from '../app/ui-widgets/formsubmit/formsubmit.component';
import { ForminputComponent } from '../app/ui-widgets/form-input/forminput.component';
import { ForminputselectComponent } from '../app/ui-widgets/forminputselect/forminputselect.component';
import { FormcreateComponent } from '../app/ui-widgets/formcreate/formcreate.component';
import { DivcreateComponent } from '../app/ui-widgets/divcreate/divcreate.component';

@NgModule({
  declarations: [
    AppComponent,
    AppDynamicPageComponent,
    AbstractViewComponent,
    WidgetTextEditorComponent,
    DatepickerComponent,
    RadiobuttonComponent,
    FormsubmitComponent,
    ForminputComponent,
    ForminputselectComponent,
    FormcreateComponent,
    DivcreateComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    EditorModule,
    ButtonModule,
    DialogModule,
    BrowserAnimationsModule,
    NgbModule,
    ChipsModule,
    TableModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
