import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-abstract-view',
  templateUrl: './abstract-view.component.html',
  styleUrls: ['./abstract-view.component.css']
})
export class AbstractViewComponent implements OnInit {
  @Input() pageJsonData;
  //@Input() testMsg;
  pageData: any[] = [];
  constructor() { }

  ngOnInit() {   
    this.pageData = this.pageJsonData; 
    //console.log(this.pageJsonData);
    // console.log(this.testMsg);
  }

}
