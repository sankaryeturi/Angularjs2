import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppDynamicPageComponent } from './app-dynamic-page.component';

describe('AppDynamicPageComponent', () => {
  let component: AppDynamicPageComponent;
  let fixture: ComponentFixture<AppDynamicPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppDynamicPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppDynamicPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
