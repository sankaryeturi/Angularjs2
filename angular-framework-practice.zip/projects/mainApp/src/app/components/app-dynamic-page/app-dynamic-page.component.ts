import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { JsonPageData } from '../../services/jsonPageDataService';

@Component({
  selector: 'app-dynamic-page',
  templateUrl: './app-dynamic-page.component.html',
  styleUrls: ['./app-dynamic-page.component.css'],
  providers: [JsonPageData]
})
export class AppDynamicPageComponent implements OnInit {
  pageJsonDataObj: any = [];
  constructor(private route: ActivatedRoute, private _jsonPageData: JsonPageData) { }

  ngOnInit() {
    this.route.data.subscribe(v => {
      this.getPageJsonData(v.parameter);
    });
  }

  getPageJsonData(pageName) {
    this._jsonPageData.getPageJson(pageName).subscribe((res)=>{
      this.pageJsonDataObj = res.components;
    });
  }

}
