export const Configuration = {
    documentAPIUrl:"http://localhost:51508/api/Documents"
}