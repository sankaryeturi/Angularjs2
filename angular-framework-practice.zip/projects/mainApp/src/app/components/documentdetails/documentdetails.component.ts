import { Component, OnInit } from '@angular/core';
import { DocumentdetailsService } from './documentdetails.service';
import { Detail, DocumentData } from './documentdetails.model';

@Component({
  selector: 'app-documentdetails',
  templateUrl: './documentdetails.component.html',
  styleUrls: ['./documentdetails.component.css']
})
export class DocumentdetailsComponent implements OnInit {
  documentData: DocumentData;
  constructor(private documentDetailsService: DocumentdetailsService) { }

  ngOnInit() {
  }

  model: Detail = {
    originalPlan: "",
    justificationOfChange: "",
    changeNeededDate: new Date(),
    changeImplemented: "1",
    changeEffectedDate: new Date(),
    implementationComment: ""
  };

  SaveDetails() {
    this.documentData = new DocumentData;
    this.documentData.details = this.model;
    this.documentDetailsService.saveDocumentDetails(this.documentData).subscribe(x => {
      console.log("Data Saved Successfully", x);
    });
  }
}
