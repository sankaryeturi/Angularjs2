import { Guid } from "guid-typescript";

export class DocumentData {
    id?: Guid;
    name: string;
    details: Detail;
}

export class Detail {
    originalPlan: string;
    justificationOfChange: string;
    changeNeededDate: Date;
    changeImplemented: string;
    changeEffectedDate: Date;
    implementationComment: string;
}