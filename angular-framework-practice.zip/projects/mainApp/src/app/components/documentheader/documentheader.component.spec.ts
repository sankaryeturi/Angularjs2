import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentheaderComponent } from './documentheader.component';

describe('DocumentheaderComponent', () => {
  let component: DocumentheaderComponent;
  let fixture: ComponentFixture<DocumentheaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocumentheaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentheaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
