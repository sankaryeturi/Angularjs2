import { Component, OnInit } from '@angular/core';
import { DocumentheaderService } from './documentheader.services';
import { Tasks } from './documentheader.interface';
import { Observable } from 'rxjs';
import { NgbModal, ModalDismissReasons, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-documentheader',
  templateUrl: './documentheader.component.html',
  styleUrls: ['./documentheader.component.css'],
  providers: [DocumentheaderService]
})

export class DocumentheaderComponent implements OnInit {
  private taskList: Tasks[];
  wellsList: any[];
  rigsList: any[];
  closeResult: string;
  addTaskForm: FormGroup;
  addTaskSubmitted = false;
  private modalRef: NgbModalRef;

  constructor(private _documentService: DocumentheaderService, 
              private modalService: NgbModal,
              private formBuilder: FormBuilder,) { }

  // for open the add task modal popup
  addTaskPopupOpen(content) {
    // this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
    //   this.closeResult = `Closed with: ${result}`;
    // }, (reason) => {
    //   this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    // });
    this.modalRef = this.modalService.open(content);
    this.modalRef.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  close() {
    this.modalRef.close();
  }
  //
  submitAddTask() {
    this.addTaskSubmitted = true;
    if (this.addTaskForm.invalid) {
      alert("invalid");
    } else {  
      //this.addTaskForm.value
      const formData = {
        "categoryName": this.addTaskForm.value.categoryName,
        "fields": this.addTaskForm.value.fields
      };
      this.taskList.push(formData);
      this.close();
    }
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }

  ngOnInit() : void {
    this.getTaskList(); 
    this.getWellsList();
    this.getRigsList();
    this.addTaskForm = this.formBuilder.group({
        categoryName: ['', Validators.required],
        fields: ['', Validators.required]
    }); 
  }

  getTaskList() {
    this._documentService.getTasks().subscribe((res : Tasks[])=>{
      this.taskList = res;
    });
  }

  getWellsList() {
    this._documentService.getWells().subscribe((res : Tasks[])=>{
      this.wellsList = res;
    });
  }

  getRigsList() {
    this._documentService.getRigs().subscribe((res : Tasks[])=>{
      this.rigsList = res;
    });
  }

}
