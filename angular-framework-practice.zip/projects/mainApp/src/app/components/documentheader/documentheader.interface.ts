export interface Tasks {
    categoryName: number;
    fields: string;    
}