import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { Tasks } from './documentheader.interface';
import { UrlConfig } from '../../configs/urls';
import { from } from 'rxjs';

@Injectable({
   providedIn: 'root'
})
export class DocumentheaderService {
   private _tasklisturl:string = UrlConfig.taskList;
   private _wellslisturl:string = UrlConfig.wellsList;
   private _rigslisturl:string = UrlConfig.rigsList;
   constructor(private httpClient: HttpClient){}
   
   // get task list
   getTasks() {
      return this.httpClient.get(this._tasklisturl);
   }

   getWells() {
      return this.httpClient.get(this._wellslisturl);
   }

   getRigs() {
      return this.httpClient.get(this._rigslisturl);
   }

}