import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { documentworkflowComponent } from './documentworkflow.component';

describe('documentworkflowComponent', () => {
  let component: documentworkflowComponent;
  let fixture: ComponentFixture<documentworkflowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ documentworkflowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(documentworkflowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
