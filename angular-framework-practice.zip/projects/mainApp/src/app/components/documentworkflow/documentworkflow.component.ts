import { Component, OnInit } from '@angular/core';
import { documentworkflowService } from './documentworkflow.service';
import { Detail, DocumentData } from './documentworkflow.model';
import { ImageUrls } from '../../configs/urls';

@Component({
  selector: 'app-documentworkflow',
  templateUrl: './documentworkflow.component.html',
  styleUrls: ['./documentworkflow.component.css']
})
export class DocumentworkflowComponent implements OnInit {
  documentData: DocumentData;
  private imageLinks: any = ImageUrls;
  constructor(private documentworkflowService: documentworkflowService) { }

  ngOnInit() {
  }

  model: Detail = {
    originalPlan: "",
    justificationOfChange: "",
    changeNeededDate: new Date(),
    changeImplemented: "1",
    changeEffectedDate: new Date(),
    implementationComment: ""
  };

  SaveDetails() {
    this.documentData = new DocumentData;
    this.documentData.details = this.model;
    this.documentworkflowService.savedocumentworkflow(this.documentData).subscribe(x => {
      console.log("Data Saved Successfully", x);
    });
  }
}
