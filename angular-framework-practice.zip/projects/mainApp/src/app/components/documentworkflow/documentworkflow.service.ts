import { Observable, throwError } from 'rxjs';
import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { retry, catchError } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { Configuration } from './configuration';

@Injectable({
  providedIn: 'root'
})
export class documentworkflowService {
  constructor(private http: HttpClient) { }
  config = Configuration;

  public savedocumentworkflow(data:any): Observable<any> {
    return this.http.post<any>(this.config.documentAPIUrl,data).pipe(map((response) => {
      return response;
    }), catchError(this.handleError));
  };

  handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // client-side error
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
  }
}