export const UrlConfig = {
    wellsList : "http://localhost:4300/wellsList",
    rigsList : "http://localhost:4300/rigsList",
    taskList: "http://localhost:4300/taskList",
    mocApi: "http://localhost:4300"
};

export const ImageUrls = {
    draft: "../assets/images/draft_img.png",
    question: "../assets/images/questions_img.png",
    approved: "../assets/images/approved_img.png",
    notify: "../assets/images/notified_img.png"
};