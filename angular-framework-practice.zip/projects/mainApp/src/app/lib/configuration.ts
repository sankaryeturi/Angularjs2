export const Configuration = {
    wellsUrl : "http://localhost:4300/wellsList"
};