import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TechnicalComponentsComponent } from './technical-components.component';

describe('TechnicalComponentsComponent', () => {
  let component: TechnicalComponentsComponent;
  let fixture: ComponentFixture<TechnicalComponentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TechnicalComponentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TechnicalComponentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
