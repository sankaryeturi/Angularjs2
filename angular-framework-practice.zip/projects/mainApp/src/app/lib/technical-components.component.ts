import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sonata-technical-components',
  template: `
    <p>
      technical-components works!
    </p>
  `,
  styles: []
})
export class TechnicalComponentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
