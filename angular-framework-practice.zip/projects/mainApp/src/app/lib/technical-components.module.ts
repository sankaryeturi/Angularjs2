import { NgModule } from '@angular/core';
import { TechnicalComponentsComponent } from './technical-components.component';
import { WellslookupComponent } from './wellslookup/wellslookup.component';
import { BrowserModule } from '@angular/platform-browser';
import { DialogModule } from 'primeng/dialog';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { ChipsModule } from 'primeng/chips';
import { TableModule } from 'primeng/table';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


@NgModule({
  declarations: [TechnicalComponentsComponent, WellslookupComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    TableModule,
    DialogModule,
    ChipsModule,
    HttpClientModule,
    FormsModule
  ],
  exports: [TechnicalComponentsComponent, WellslookupComponent]
})
export class TechnicalComponentsModule { }
