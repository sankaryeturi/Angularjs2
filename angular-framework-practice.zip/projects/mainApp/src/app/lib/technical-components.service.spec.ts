import { TestBed } from '@angular/core/testing';

import { TechnicalComponentsService } from './technical-components.service';

describe('TechnicalComponentsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: TechnicalComponentsService = TestBed.get(TechnicalComponentsService);
    expect(service).toBeTruthy();
  });
});
