import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WellslookupComponent } from './wellslookup.component';

describe('WellslookupComponent', () => {
  let component: WellslookupComponent;
  let fixture: ComponentFixture<WellslookupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WellslookupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WellslookupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
