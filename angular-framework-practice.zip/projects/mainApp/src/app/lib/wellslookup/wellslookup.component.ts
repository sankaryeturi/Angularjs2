import { Component, OnInit } from '@angular/core';
import { WellsService } from './wellslookup.service';
import { Wells } from './wellslookup.model';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'sonata-wellslookup',
  templateUrl: './wellslookup.component.html',
  styleUrls: ['./wellslookup.component.css']
})
export class WellslookupComponent implements OnInit {
  display: boolean = false;
  wellsDetails: Wells[] = [];
  well: Wells;
  cols: any[];
  wellNames: any[] = [];
  selectedWells: Wells[];

  constructor(private service: WellsService) { }

  ngOnInit() {
    this.getData();
    this.displayForm();
    this.cols = [
      { field: 'id', header: 'Id' },
      { field: 'wellName', header: 'Name' }
    ];
  }

  displayForm(form?: NgForm) {
    this.service.formData = {
      id: '',
      wellName: '',
    };
  }

  showDialog() {
    this.display = true;
  }

  populateForm(pd: Wells) {
    let find_name = this.wellNames.find(x => x == pd.wellName);
    let remove_name = this.wellNames.findIndex(x => x == pd.wellName);
    if (find_name == undefined) {
      this.wellNames.push(pd.wellName);
    }
    else {
      this.wellNames.splice(remove_name, 1);
    }
    this.display = false;
  }

  Remove(e: any) {
    let delete_name = this.selectedWells.findIndex(x => x.wellName == e.value);
    if (delete_name >= 0) {
      let remove = this.selectedWells.map(x => Object.assign({}, x));
      remove.splice(delete_name, 1);
      this.selectedWells = remove;
    }

  }

  closeDialog() {
    this.display = false;
  }

  getData() {
    this.service.getList().subscribe(data => {
      this.wellsDetails = data;
    });
  }
}
