export class Wells {
    id? : string;
    wellName? : string;
}
