import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Wells } from  './wellslookup.model';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Configuration } from '../configuration';

@Injectable({
  providedIn: 'root'
})
export class WellsService {

  formData: Wells;
  list : Wells[];
  readonly rootUrl = Configuration.wellsUrl;
  constructor(private http: HttpClient) { }

  getList():Observable<Wells[]>{
    return this.http.get<Wells[]>(this.rootUrl).pipe(map((response) => {
      return response;
    }));
  }

}
