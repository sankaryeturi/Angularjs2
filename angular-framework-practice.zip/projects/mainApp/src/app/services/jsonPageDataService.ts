
import { Injectable } from '@angular/core';
import { HttpResponseBase, HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';
import { UrlConfig } from '../configs/urls';
@Injectable()
export class JsonPageData {
  private _mockApi:string = UrlConfig.mocApi;
  constructor(private httpClient: HttpClient) {}

  public getPageJson(pagename) {
    return this.httpClient.get("../assets/metadataDriven/"+ pagename +"-layout.json");
  }
}
