import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-widget-datepicker',
  templateUrl: './datepicker.component.html'
})
export class DatepickerComponent implements OnInit {
  @Input() componentInfo;
  constructor() { }

  ngOnInit() {   }

}
