import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-widget-divcreate',
  templateUrl: './divcreate.component.html'
})
export class DivcreateComponent implements OnInit {
  @Input() componentInfo;
  constructor() { }

  ngOnInit() {   }

}
