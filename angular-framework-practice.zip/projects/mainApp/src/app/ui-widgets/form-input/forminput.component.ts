import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-widget-forminput',
  templateUrl: './forminput.component.html'
})
export class ForminputComponent implements OnInit {
  @Input() componentInfo;
  constructor() { }

  ngOnInit() {   }

}
