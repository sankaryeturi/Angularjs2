import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-widget-formcreate',
  templateUrl: './formcreate.component.html'
})
export class FormcreateComponent implements OnInit {
  @Input() componentInfo;
  constructor() { }

  ngOnInit() {   }

}
