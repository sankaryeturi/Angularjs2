import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-widget-formselect',
  templateUrl: './forminputselect.component.html'
})
export class ForminputselectComponent implements OnInit {
  @Input() componentInfo;
  constructor() { }

  ngOnInit() {   }

}
