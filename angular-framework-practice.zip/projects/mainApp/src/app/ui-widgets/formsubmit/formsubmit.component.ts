import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-widget-formsubmit',
  templateUrl: './formsubmit.component.html'
})
export class FormsubmitComponent implements OnInit {
  @Input() componentInfo;
  constructor() { }

  ngOnInit() {   }

}
