import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-widget-radiobutton',
  templateUrl: './radiobutton.component.html'
})
export class RadiobuttonComponent implements OnInit {
  @Input() componentInfo;
  constructor() { }

  ngOnInit() {   }

}
