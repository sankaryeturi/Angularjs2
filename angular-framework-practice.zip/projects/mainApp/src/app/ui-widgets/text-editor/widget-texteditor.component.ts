import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-widget-texteditor',
  templateUrl: './widget-texteditor.component.html'
})
export class WidgetTextEditorComponent implements OnInit {
  @Input() componentInfo;
  constructor() { }

  ngOnInit() {   }

}
