'use strict';

angular.module('myApp.view1', ['ngRoute', 'ngJsonExportExcel'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/view1', {
    templateUrl: 'view1/view1.html',
    controller: 'View1Ctrl'
  });
}])

.controller('View1Ctrl', ['$scope', '$http', function($scope, $http) {
  $scope.dataList = [];
  var url = "http://localhost:3000/clinicData";
  $http.get(url).then(function (response) {
      $scope.dataList = response.data;
      //console.log($scope.dataList);
  });

  $scope.Export = function () {
    var head = [["Clinic Name", "Address", "Opening hours(Mon - Fri)", "Opening hours(Sat)", "Opening hours(Sun)", "Opening hours(PH)", "Doctor Name","Contact No"]];
    var body = [
        [1, "Denmark", 7.526, "Copenhagen"],
        [2, "Switzerland", 	7.509, "Bern"],
        [3, "Iceland", 7.501, "Reykjavík"],
        [4, "Norway", 7.498, "Oslo"],
        [5, "Finland", 7.413, "Helsinki"]
    ];

    var doc = new jsPDF();
    doc.autoTable({
      head: head, 
      body: body,
      columnStyles: {
          columnWidth: 'auto'        
      }
    });
    doc.save("dataurlnewwindow");
  }

  $scope.printFile = function() {
    var pages = ['files/pdf.pdf', 'files/avinash.pdf'];
    //printJS('../files/avinash.jpg');

    printJS({
      printable: ['../files/avinash.jpg'],
      type: 'image',
      header: 'Multiple Images',
      imageStyle: 'width:50%;margin-bottom:20px;'
    });
  }
}]);