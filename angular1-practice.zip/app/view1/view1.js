'use strict';

angular.module('myApp.view1', ['ngRoute', 'ngJsonExportExcel'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/view1', {
    templateUrl: 'view1/view1.html',
    controller: 'View1Ctrl'
  });
}])

.controller('View1Ctrl', ['$scope', '$http', function($scope, $http) {
  $scope.dataList = [];
  var url = "http://localhost:3000/clinicData";
  $http.get(url).then(function (response) {
      $scope.dataList = response.data;
      console.log($scope.dataList);
  });
  
}]);