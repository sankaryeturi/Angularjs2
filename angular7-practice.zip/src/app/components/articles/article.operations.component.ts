// ====================================================
// More Templates: https://www.ebenmonney.com/templates
// Email: support@ebenmonney.com
// ====================================================

import { Component } from '@angular/core';
import { fadeInOut } from '../../services/animations';
import { ArticlesService } from './articles.services';
import { Articles } from './articles.interface';


@Component({
  //selector: 'app-customers',
  templateUrl: './article.operations.html',
  styleUrls: ['./articles.component.css'],
  animations: [fadeInOut],
  providers: [ArticlesService]
})
export class ArticleOperationComponent {
  articles: Articles[];
  constructor(private _articles: ArticlesService) {

  }

  ngOnInit() : void {
    
  }
}
