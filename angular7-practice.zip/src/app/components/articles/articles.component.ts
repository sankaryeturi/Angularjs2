// ====================================================
// More Templates: https://www.ebenmonney.com/templates
// Email: support@ebenmonney.com
// ====================================================

import { Component } from '@angular/core';
import { fadeInOut } from '../../services/animations';
import { ArticlesService } from './articles.services';
import { Articles } from './articles.interface';


@Component({
  //selector: 'app-customers',
  templateUrl: './articles.component.html',
  styleUrls: ['./articles.component.css'],
  animations: [fadeInOut],
  providers: [ArticlesService]
})
export class ArticlesComponent {
  articles: Articles[];
  constructor(private _articles: ArticlesService) {

  }

  ngOnInit() : void {
    this._articles.getarticles()
    .subscribe(articles => this.articles = articles);
  }
}
