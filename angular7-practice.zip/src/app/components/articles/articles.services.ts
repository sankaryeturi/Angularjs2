import { Injectable } from '@angular/core';
import { Http , Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import { Articles } from './articles.interface';

@Injectable()
export class ArticlesService {
   private _articleurl='http://localhost:3000/articles';
   constructor(private _http: Http){}
   
   getarticles(): Observable<Articles[]> {
      return this._http.get(this._articleurl)
      .map((response: Response) => <Articles[]> response.json())
      .do(data => console.log(JSON.stringify(data)));
   }
}