// ====================================================
// More Templates: https://www.ebenmonney.com/templates
// Email: support@ebenmonney.com
// ====================================================

import { Component } from '@angular/core';
import { fadeInOut } from '../../services/animations';
import { ArticlesService } from './articles.services';
import { Articles } from './articles.interface';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  //selector: 'app-customers',
  templateUrl: './article.operations.html',
  styleUrls: ['./articles.component.css'],
  animations: [fadeInOut],
  providers: [ArticlesService]
})
export class ArticleOperationComponent {
  registerForm: FormGroup;
  submitted = false;
  constructor(private _articles: ArticlesService, private formBuilder: FormBuilder) {

  }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
        language: ['', Validators.required],
        category: ['', Validators.required],
        subcategory: ['', Validators.required],
        articletitle: ['', Validators.required],
        lastName: ['', Validators.required],
        email: ['', [Validators.required, Validators.email]],
        password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  // convenience getter for easy access to form fields
  get f() { return this.registerForm.controls; }

  onSubmit() {
    alert()
    this.submitted = true;

    // stop here if form is invalid
    if (this.registerForm.invalid) {
        return;
    }

    //alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.value))
  }
}
