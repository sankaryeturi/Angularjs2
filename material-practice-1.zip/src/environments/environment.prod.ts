// ====================================================
// More Templates: https://www.ebenmonney.com/templates
// Email: support@ebenmonney.com
// ====================================================

export const environment = {
    production: true,
    baseUrl: null, // Change this to the address of your backend API if different from frontend address
    loginUrl: '/login'
};
