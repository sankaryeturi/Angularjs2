import { Component } from '@angular/core';
import { Users } from './user.interface';
import { UsersService } from './user.services';

@Component({
  templateUrl: './users.component.html',
  providers: [UsersService]
})
export class UsersComponent {
  users: Users[];

  constructor(private _usersservices: UsersService) { }

  ngOnInit() : void {
    this._usersservices.getUsers()
      .subscribe(users => this.users = users);
  }

}
