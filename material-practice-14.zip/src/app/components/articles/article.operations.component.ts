import { Component } from '@angular/core';
import { ArticlesService } from './articles.services';
import { CommonService } from '../../services/common.services';
import { Articles } from './articles.interface';
import { Categories } from '../../interfaces/common.interface';
import { SubCategories } from '../../interfaces/common.interface';
import { Languages } from '../../interfaces/common.interface';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from "@angular/router";
import { NgbModal, ModalDismissReasons, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { Lightbox } from 'ngx-lightbox';
import { LightboxEvent, LIGHTBOX_EVENT } from 'ngx-lightbox';
import { Subscription } from 'rxjs';

@Component({
  //selector: 'app-customers',
  templateUrl: './article.operations.html',
  styleUrls: ['./articles.component.css'],  
  providers: [ArticlesService, CommonService]
})

export class ArticleOperationComponent {
  articleForm: FormGroup;
  categoryForm: FormGroup;
  subCategoryForm: FormGroup;
  articleSubmitted = false;
  categorySubmitted = false;  
  subCategorySubmitted = false;  
  articleInfo: Articles[];
  categories: Categories[];
  subCategories: SubCategories[];
  languages: Languages[];
  closeResult: string;
  modalReference: NgbModalRef;
  private _subscription: Subscription;
  private _albums = [];
  
  public editorOptions: Object = {
    placeholderText: 'Edit Your Content Here!',
    charCounterCount: true
  }

  public articlePageStatus = {
    articleViewPage: false,
    articleFormPage: false
  }

  constructor(private _articles: ArticlesService, 
              private formBuilder: FormBuilder, 
              private route: ActivatedRoute,
              private _commonservices: CommonService,
              private modalService: NgbModal,
              private _router: Router,
              private _lightbox: Lightbox,
              private _lightboxEvent: LightboxEvent
              ) {
                for (let i = 1; i <= 4; i++) {
                  const src = 'assets/images/user.jpg';
                  const caption = 'Image ' + i + ' caption here';
                  const thumb = 'assets/images/user.jpg';
                  const album = {
                     src: src,
                     caption: caption,
                     thumb: thumb
                  };
                  this._albums.push(album);
                }
            }

  open(index: number): void {   
    this._lightbox.open(this._albums, index, { wrapAround: true, showImageNumberLabel: true });
  }       
  
  close(): void {
    // close lightbox programmatically
    this._lightbox.close();
  }            
  //script for category popup
  public categoryPopup(categorypopup) {
    this.modalReference = this.modalService.open(categorypopup);
    this.modalReference.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  //script for sub-category popup
  public subCategoryPopup(subCategorypopup) {
    this.modalReference = this.modalService.open(subCategorypopup);
    this.modalReference.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }

  //script for save category
  public submitCategory() {
    // stop here if form is invalid
    if (this.articleForm.invalid) {
      return;
    } else { 
      this.categorySubmitted = true;
      this._commonservices.addCategory(this.categoryForm.value)
        .subscribe(response => {
          this.getCategories();
          this.modalReference.close();
          this.categoryForm.reset();
        }); 
    }
  }

  //script for save sub category
  public submitSubCategory() {
    if (this.subCategoryForm.invalid) {
      return;
    } else { 
      this.subCategorySubmitted = true;
      this._commonservices.addSubCategory(this.subCategoryForm.value)
        .subscribe(response => {
          this.getSubCategories();
          this.modalReference.close();
          this.subCategoryForm.reset();
        });
    }    
  }

  // convenience getter for easy access to form fields
  get f() { return this.articleForm.controls; }
  get c() { return this.categoryForm.controls; }
  get sc() { return this.subCategoryForm.controls; }

  submitArticle() {
    this.articleSubmitted = true;
    // stop here if form is invalid
    if (this.articleForm.invalid) {
        return;
    } else {   
      const monthNames = ["January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
      ];
      var date = new Date();
      var day = date.getDate();
      var month = monthNames[date.getMonth() + 1];
      var year = date.getFullYear() + 1;
      this.articleForm.value.date = day + " " + month + " " + year;

      const articleAction = this.route.snapshot.paramMap.get("action");
      if (articleAction == "create") {
        this._articles.addArticle(this.articleForm.value)
            .subscribe(response => {
              this._router.navigate(['/articles']);
            });
      } else if(articleAction == "edit") {
        this._articles.updateArticle(this.articleForm.value)
            .subscribe(response => {
              this._router.navigate(['/articles']);
            });
      }      
    }
  }

  getCategories() {
    this._commonservices.getcategories().subscribe(categories => this.categories = categories);
  }

  getSubCategories() {
    this._commonservices.getsubcategories().subscribe(subcategories => this.subCategories = subcategories);
  }

  ngOnInit() {
    const articleAction = this.route.snapshot.paramMap.get("action");
    const articleId = this.route.snapshot.paramMap.get("id");

    // getting article information based on articleID
    if(articleId) {
      this._articles.getarticleinfo(articleId)
      .subscribe(articleInfo => {
        this.articleInfo = articleInfo;
        this.$element.html(content);
      });      
    }

    if (articleAction == "create" || articleAction == "edit") {
      this.articlePageStatus.articleFormPage = true;
      this.getCategories();
      this.getSubCategories();
      this._commonservices.getlanguages().subscribe(languages => this.languages = languages);      
    } else if(articleAction == "view") {
      this.articlePageStatus.articleViewPage = true
    }    

    this.articleForm = this.formBuilder.group({
        language: ['', Validators.required],
        category: ['', Validators.required],
        subCategory: ['', Validators.required],
        articleTitle: ['', Validators.required],
        articleDescription: ['', Validators.required],
        keywords: ['', Validators.required],
        status: ['', Validators.required]
    });

    this.categoryForm = this.formBuilder.group({
      categoryName: ['', Validators.required]
    });
    this.subCategoryForm = this.formBuilder.group({
      categoryName: ['', Validators.required],
      subCategoryName: ['', Validators.required],
    });
  }
}
