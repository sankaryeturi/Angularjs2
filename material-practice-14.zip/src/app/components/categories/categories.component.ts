import { Component } from '@angular/core';
import { CommonService } from '../../services/common.services';
import { Categories } from '../../interfaces/common.interface';
import { SubCategories } from '../../interfaces/common.interface';
import { NgbModal, ModalDismissReasons, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  //selector: 'app-customers',
  templateUrl: './categories.component.html',
  //styleUrls: ['../../../../node_modules/bootstrap/dist/css/bootstrap.min.css'],
  providers: [CommonService]
})
export class CategoriesComponent {
  categories: Categories[];
  subCategories: SubCategories[];
  modalReference: NgbModalRef;
  closeResult: string;
  categoryForm: FormGroup;
  subCategoryForm: FormGroup;
  categorySubmitted = false;
  subCategorySubmitted = false;

  constructor(private _commonservices: CommonService,
              private modalService: NgbModal,
              private formBuilder: FormBuilder) {

  }

  get c() { return this.categoryForm.controls; }
  get sc() { return this.subCategoryForm.controls; }

  // get the categeory list
  getCategories() {
    this._commonservices.getcategories().subscribe(categories => {      
      categories.forEach(function(e){
        e.status = false;
      });
      this.categories = categories;
    });
  }

  //script for save category
  public submitCategory() {
    if (this.categoryForm.invalid) {
      return;
    } else {  
      this.categorySubmitted = true;
      this.categoryForm.value.activeStatus = true;
      this._commonservices.addCategory(this.categoryForm.value)
        .subscribe(response => {
          this.getCategories();
          this.modalReference.close();
          this.categoryForm.reset();
        });
    }    
  }

  //script for save sub category
  public submitSubCategory() {
    this.subCategorySubmitted = true;
    this._commonservices.addSubCategory(this.subCategoryForm.value)
      .subscribe(response => {
        //this.getSubCategories();
        this.modalReference.close();
        this.subCategoryForm.reset();
      });
  }

  public deleteCategory(id) {
    this._commonservices.deleteCategory(id)
        .subscribe(response => {
          this.getCategories();          
        });
  }

  public collaps(id) {
    this.categories[id-1].status = false;
  }

  //
  categoryEdit(id) {
    this.categories.forEach(function(e){
      e.status = false;
    });
    this.categories[id-1].status = true;
  }

  updateCategory(categeoryInfo) {
    //updateCategory
    this._commonservices.updateCategory(categeoryInfo)
        .subscribe(response => {
          this.categories[categeoryInfo.id-1].status = false;
        });
  }

  //script for category popup
  public categoryPopup(categorypopup) {
    this.modalReference = this.modalService.open(categorypopup);
    this.modalReference.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  //script for sub-category popup
  public subCategoryPopup(subCategorypopup) {
    this.modalReference = this.modalService.open(subCategorypopup);
    this.modalReference.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }

  ngOnInit() : void {
    this.getCategories();
    this.categoryForm = this.formBuilder.group({
      categoryName: ['', Validators.required]
    });

    this.subCategoryForm = this.formBuilder.group({
      categoryName: ['', Validators.required],
      subCategoryName: ['', Validators.required],
    });
  }

}
