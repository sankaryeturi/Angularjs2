import { Component } from '@angular/core';
import { DashboardService } from './dashboard.services';
import { ArticlesService } from '../articles/articles.services';
import { Articles } from '../articles/articles.interface';

@Component({
  //selector: 'app-customers',
  templateUrl: './dashboard.component.html',
  providers: [DashboardService, ArticlesService],
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent {
  articles: Articles[];
  constructor(private _articles: ArticlesService) {

  }

  ngOnInit() : void {
     this._articles.getarticles()
     .subscribe(articles => this.articles = articles);    
  }
}
