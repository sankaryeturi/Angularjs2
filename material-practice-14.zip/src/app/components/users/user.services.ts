import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import { Users } from './user.interface';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable()
export class UsersService {
   private _usersurl='http://localhost:3000/users';
   constructor(private _http: Http){}
   
   // get article list
   getUsers(): Observable<Users[]> {
      return this._http.get(this._usersurl)
      .map((response: Response) => <Users[]> response.json())
      .do(data => JSON.stringify(data));
   }   
}