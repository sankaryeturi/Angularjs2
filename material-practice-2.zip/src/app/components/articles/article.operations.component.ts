
import { Component } from '@angular/core';
import { fadeInOut } from '../../services/animations';
import { ArticlesService } from './articles.services';
import { Articles } from './articles.interface';
import { Categories } from './articles.interface';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from "@angular/router";

@Component({
  //selector: 'app-customers',
  templateUrl: './article.operations.html',
  styleUrls: ['./articles.component.css'],
  animations: [fadeInOut],
  providers: [ArticlesService]
})

export class ArticleOperationComponent {
  articleForm: FormGroup;
  submitted = false;
  articleInfo: Articles[];
  categories: Categories[];
  public editorOptions: Object = {
    placeholderText: 'Edit Your Content Here!',
    charCounterCount: true,
    minHeight: 300
  }

  public articlePageStatus = {
    articleView: false,
    articleForm: false
  }

  constructor(private _articles: ArticlesService, 
              private formBuilder: FormBuilder, 
              private route: ActivatedRoute) {
  }

  ngOnInit() {
    const articleAction = this.route.snapshot.paramMap.get("action");
    const articleId = this.route.snapshot.paramMap.get("id");

    // getting article information based on articleID
    if(articleId) {
      this._articles.getarticleinfo(articleId)
      .subscribe(articleInfo => 
        this.articleInfo = articleInfo
      );      
    }

    if (articleAction == "create" || articleAction == "edit") {
      this.articlePageStatus.articleForm = true;
      this._articles.getcategories().subscribe(categories => this.categories = categories);
    } else if(articleAction == "view") {
      this.articlePageStatus.articleView = true
    }    

    this.articleForm = this.formBuilder.group({
        language: ['', Validators.required],
        category: ['', Validators.required],
        subcategory: ['', Validators.required],
        articletitle: ['', Validators.required],
        article: ['', Validators.required],
        keywords: ['', Validators.required],
    });
  }

  // convenience getter for easy access to form fields
  get f() { return this.articleForm.controls; }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.articleForm.invalid) {
        return;
    }

    //alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.articleForm.value))
  }
}
