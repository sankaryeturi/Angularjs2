export interface Articles {
    id: number;
    articleTitle: string;
    language: string;
    category: string;
    subCategory: string;
    articleDescription: string;
    keywords: string;
    attachments: string;
    status: string;
}

export interface Categories {
    id: number;
    key: string;
    name: string;
    value: string;
}



