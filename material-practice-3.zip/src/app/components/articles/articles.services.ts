import { Injectable } from '@angular/core';
import { Http , Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import { Articles } from './articles.interface';
//import { Categories } from './articles.interface';

@Injectable()
export class ArticlesService {
   private _articleurl='http://localhost:3000/articles';
   private _categoryurl='http://localhost:3000/category';
   constructor(private _http: Http){}
   
   // get article list
   getarticles(): Observable<Articles[]> {
      return this._http.get(this._articleurl)
      .map((response: Response) => <Articles[]> response.json())
      .do(data => JSON.stringify(data));
   }

   // get article info based on articleID
   getarticleinfo(articleID:any): Observable<Articles[]> {
      return this._http.get(this._articleurl + "/"+articleID)
      .map((response: Response) => <Articles[]> response.json())
      .do(data => data);
   }

   addArticle(formData): Observable<Articles[]> {
      return this._http.post(this._articleurl, formData)
      .map((response:Response) =>  <Articles[]> response.json())
      .do(data => data);
      
   }

   // get category list
   // getcategories(): Observable<Categories[]> {
   //    return this._http.get(this._categoryurl)
   //    .map((response: Response) => <Categories[]> response.json())
   //    .do(data => data);
   // }

   
}