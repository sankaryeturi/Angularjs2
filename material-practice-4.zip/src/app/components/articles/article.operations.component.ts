import { Component } from '@angular/core';
import { fadeInOut } from '../../services/animations';
import { ArticlesService } from './articles.services';
import { CommonService } from '../../services/common.services';
import { Articles } from './articles.interface';
import { Categories } from '../../interfaces/common.interface';
import { SubCategories } from '../../interfaces/common.interface';
import { Languages } from '../../interfaces/common.interface';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from "@angular/router";

@Component({
  //selector: 'app-customers',
  templateUrl: './article.operations.html',
  styleUrls: ['./articles.component.css'],
  animations: [fadeInOut],
  providers: [ArticlesService, CommonService]
})

export class ArticleOperationComponent {
  articleForm: FormGroup;
  submitted = false;
  articleInfo: Articles[];
  categories: Categories[];
  subCategories: SubCategories[];
  languages: Languages[];

  public editorOptions: Object = {
    placeholderText: 'Edit Your Content Here!',
    charCounterCount: true
  }

  public articlePageStatus = {
    articleViewPage: false,
    articleFormPage: false
  }

  constructor(private _articles: ArticlesService, 
              private formBuilder: FormBuilder, 
              private route: ActivatedRoute,
              private _commonservices: CommonService
              ) {
  }

  ngOnInit() {
    const articleAction = this.route.snapshot.paramMap.get("action");
    const articleId = this.route.snapshot.paramMap.get("id");

    // getting article information based on articleID
    if(articleId) {
      this._articles.getarticleinfo(articleId)
      .subscribe(articleInfo => 
        this.articleInfo = articleInfo
      );      
    }

    if (articleAction == "create" || articleAction == "edit") {
      this.articlePageStatus.articleFormPage = true;
      this._commonservices.getcategories().subscribe(categories => this.categories = categories);
      this._commonservices.getlanguages().subscribe(languages => this.languages = languages);
      this._commonservices.getsubcategories().subscribe(subcategories => this.subCategories = subcategories);
    } else if(articleAction == "view") {
      this.articlePageStatus.articleViewPage = true
    }    

    this.articleForm = this.formBuilder.group({
        language: ['', Validators.required],
        category: ['', Validators.required],
        subCategory: ['', Validators.required],
        articleTitle: ['', Validators.required],
        articleDescription: ['', Validators.required],
        keywords: ['', Validators.required],
        status: ['', Validators.required]
    });
  }

  // convenience getter for easy access to form fields
  get f() { return this.articleForm.controls; }

  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.articleForm.invalid) {
        return;
    } else {      
      this._articles.addArticle(this.articleForm.value)
      .subscribe(response => console.log(response.ok));
    }
  }
}
