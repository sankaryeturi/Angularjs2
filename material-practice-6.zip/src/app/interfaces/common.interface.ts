
export interface Categories {
    id: number;
    key: string;
    name: string;
}

export interface SubCategories {
    id: number;
    key: string;
    name: string;
}

export interface Languages {
    id: number,
    name: string,
    shortName: string
}

