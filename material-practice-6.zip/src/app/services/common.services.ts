import { Injectable } from '@angular/core';
import { Http , Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import { Categories } from '../interfaces/common.interface';
import { SubCategories } from '../interfaces/common.interface';
import { Languages } from '../interfaces/common.interface';

@Injectable()
export class CommonService {
   private _categoryurl='http://localhost:3000/category';
   private _languageurl='http://localhost:3000/languages';
   private _subcategoryurl='http://localhost:3000/subcategory';
   constructor(private _http: Http){}
   
   // get category list
   getcategories(): Observable<Categories[]> {
      return this._http.get(this._categoryurl)
      .map((response: Response) => <Categories[]> response.json())
      .do(data => data);
   }

   // get sub-category list
   getsubcategories(): Observable<SubCategories[]> {
      return this._http.get(this._subcategoryurl)
      .map((response: Response) => <SubCategories[]> response.json())
      .do(data => data);
   }

   // get languages list
   getlanguages(): Observable<Languages[]> {
      return this._http.get(this._languageurl)
      .map((response: Response) => <Languages[]> response.json())
      .do(data => data);
   }

   
}