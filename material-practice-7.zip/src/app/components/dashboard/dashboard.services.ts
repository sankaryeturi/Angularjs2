import { Injectable } from '@angular/core';
import { Http , Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
//import { Articles } from '../articles/articles.services';
//import { Categories } from './articles.interface';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable()
export class DashboardService {
   private _articleurl='http://localhost:3000/articles';
   private _categoryurl='http://localhost:3000/category';
   constructor(private _http: Http){}
   
}