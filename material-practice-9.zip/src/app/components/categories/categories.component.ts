import { Component } from '@angular/core';
import { CommonService } from '../../services/common.services';
import { Categories } from '../../interfaces/common.interface';

@Component({
  //selector: 'app-customers',
  templateUrl: './categories.component.html',
  //styleUrls: ['../../../../node_modules/bootstrap/dist/css/bootstrap.min.css'],
  providers: [CommonService]
})
export class CategoriesComponent {
  categories: Categories[];
  constructor(private _commonservices: CommonService,) {

  }

  getCategories() {
    this._commonservices.getcategories().subscribe(categories => this.categories = categories);
  }
  ngOnInit() : void {
    this.getCategories();
  }
}
