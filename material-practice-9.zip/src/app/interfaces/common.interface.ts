
export interface Categories {
    id: number;
    key: string;
    categoryName: string;
}

export interface SubCategories {
    id: number;
    key: string;
    categoryName: string;
    subCategoryName: string;
}

export interface Languages {
    id: number,
    name: string,
    shortName: string
}