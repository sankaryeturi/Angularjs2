export interface Users {
    id: string,
    userName: string,
    fullName: string,
    email: string,
    jobTitle: string,
    phoneNumber: string,
    configuration: string,
    isEnabled: true,
    isLockedOut: true,
    roles: any
  }